def f(x,y):
    z=3
    print(x, y)
    print("x * y is ", x*y)
    print("z is", z)

z=3
f(3,2)


def testify(arg1, *argv):
    print("first argument :", arg1)
    for arg in argv:
        print("Next argument through *argv:", arg)

testify("Naruto","Kaneki","Eren","Vegeta")
