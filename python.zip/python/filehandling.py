file = "python.txt"
f = open(file, 'a') # a means adding something in the file
text = f.write("I am adding a new line in this txt")
print(text)
f.close()
