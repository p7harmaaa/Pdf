import sys
print("Hello world")

basket = {'sin','last','war'}
print(basket)
'last' in basket

a = "Hello World"
print(a.strip()) # returns "Hello World"

print(2+2)
print(4*2)
print(4//3)
print(4**3)

print("Number of arguments :", len(sys.argv), "arguments.")
print("Arguments list:", str(sys.argv))
#import sysprint((int(sys.argv[1]))+(int(sys.argv[2])))
