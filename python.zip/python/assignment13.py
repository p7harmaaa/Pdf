"""
file = "Assignment13.txt"
f = open(file,'a')
text = f.write("I am adding a new line in this text")
print(text)
f.close()
"""

with open("Assignment13.txt") as f:
    with open("Output_Assignment13.txt", "w") as f1:
        for line in f:
            f1.write(line)

f.close()
f1.close()
