
# coding: utf-8

# # Day 1

# ## Problem 1

# In[2]:


name = input("Enter your name:")
print("Hello,", name)


# ## Problem 2

# In[4]:


print("Enter two number")
num1 = int(input())
num2 = int(input())
sum = num1+num2
if(sum>=0):
    print("it is a positive number,sum:", sum)
else:
    print("it is a negative number,sum:", sum)


# ## Problem 3

# In[11]:


x = 1234
a =input("Enter the number:")
num = int(a)

while(num!=x):
    print("Incorrect")
    a = input()
    num = int(a)
    if(num == x):
        break
    else:
        continue
if(num == x):
    print("correct")


# ## Problem 4

# In[17]:


var1 = input("enter your first name")
var2 = input("enter your last name")
class Concat:
    def __init__(self,var1,var2):
        self.var1 = var1
        self.var2 = var2
    def concat(self):
        return (self.var1 + self.var2)
object = Concat(var1,var2).concat()
print(object)


# ## Problem 5

# In[18]:


str = "Hello, How are you?"
print(str.swapcase())


# ## Problem 6

# In[19]:


a = [1,2,3,4]
sum = 0 
multiply = 1
for i in a:
    sum = sum + i
    multiply = multiply * i
print(sum)
print(multiply)


# ## Problem 7

# In[20]:


a = [12,15,18,20,22,24,26]
x = int(input("Enter the number:"))

i = 0 
while(i<len(a)):
    if(x==a[i]):
        print("True")
        break
    i=i+1

if(i>=len(a)):
    print("False")


# ## Problem 8

# In[24]:


a = [1,2,3,4]
b = [4,5,6,7]
def is_member(a,b):
    count = 0 
    for x in a:
        for y in b:
            if(x==y):
                count = count + 1
    if(count>0):
        print("True")
    else:
        print("False")

is_member(a,b)


# ## Problem 9

# In[25]:


#a = [int(x) for x in input().split()]
a = [4,9,7]
for i in a:
    while(i>0):
        print("*", end = "")
        i-=1
    print("\n")


# # Day 2

# ## Problem 1

# In[28]:


def generate_n_chars(n,ch):
    while(n>0):
        print(ch, end="")
        n-=1

generate_n_chars(5,"x")


# ## Problem 2

# In[31]:


a = [int(x) for x in input().split()]
def max_in_list(a):
    max = a[0]
    for x in a:
        if(max<x):
            max =x
        else:
            continue
    print(max)

max_in_list(a)


# ## Problem 3

# In[35]:


def map_to_lengths_for(words):
    length = []
    for word in words:
        length.append(len(word))
    return length

words = ["Naruto", "Kaneki", "Eren"]
print(map_to_lengths_for(words))


# ## Problem 4

# In[1]:


words = ["Hello", "Naruto", "Eren"]
lengths = list(map(lambda x: len(x), words))
print(max(lengths))


# ## Problem 5

# In[39]:


def filter_long_words(words, n):
    new_list = []
    i = 0
    while(i<len(words)):
        if(len(words[i])>n):
            new_list.append(words[i])
        i+=1
    return new_list
words = ["Naruto", "Goku", "Kaneki"]
n = 4
new_list = filter_long_words(words,n)
print(new_list)


# In[2]:


words = ["Naruto", "Goku", "Kaneki"]
n = 3
new_list = list(filter(lambda x: len(x)>n, words))
print(new_list)


# ## Problem 6

# In[16]:


import string

def palindrome(phrase):
    punctuation = string.punctuation + " "
    
    clean_phrase = ""
    for letter in phrase:
        if letter not in punctuation:
            clean_phrase += letter.lower()
            
    return clean_phrase == clean_phrase[::-1]

print(palindrome("Go hang a salami I'm a lasagna hog."))
print(palindrome("Was it a rat I saw?"))
print(palindrome("Step on no pets"))
print(palindrome("Sit on a potato pan, Otis!"))
print(palindrome("Lisa Bonet ate no basil"))
print(palindrome("Satan, oscillate my metallic sonatas"))
print(palindrome("I roamed under it as a tired nude Maori"))
print(palindrome("Rise to vote sir"))
print(palindrome("Dammit, I'm mad!"))
print(palindrome("This is not a palindrome"))
print(palindrome("Hello"))


# ## Problem 7

# In[2]:


def is_pangram(phrase):
    alphabet  ="abcdefghijklmnopqrstuvwxyz"
    for char in alphabet:
        if char not in phrase:
            print(char)
            return False
    return True

myPhrase = "The quick brown fox jumps over the lazy dog"
print(is_pangram(myPhrase))


# ## Problem 8

# In[3]:


list = ["merry", "christmas", "and", "happy", "new", "year"]
dict = {"merry" : "god", "christmas" : "jul", "and" : "och", "happy" : "gott", "new" : "nytt", "year" : "ar"}

def translate(list):
    new_list = []
    for i in list:
        new_list.append(dict[i])
    return new_list

new_list = translate(list)
print(new_list)


# ## Problem 9

# In[4]:


"""
word = "Hello"
from collections import Counter
word = "Hello"
counts = Counter(word)
for i in word:
    print(i,counts[i])
print(counts)
"""

def char_frequency(str1):
    dict = {}
    for n in str1:
        keys = dict.keys()
        if n in keys:
            dict[n] = dict[n] + 1
        else:
            dict[n] = 1
    return dict
print(char_frequency("google.com"))
               


# ## Problem 10

# In[5]:


a = [5,6,7,8,9]
b = [1,2,3,4]
list = [5,1,3,2,8] 
def add(a,b):
    i=0
    c=[]
    while(i<len(a) or i<len(b)):
        if(i<len(a) and i<len(b)):
            c.append(a[i] + b[i])
        elif(i<len(a) and i>=len(b)):
            c.append(a[i])
        elif(i>=len(a) and i<len(b)):
            c.append(b[i])
        i=i+1
    print(c)

add(a,b)

def subtract(a,b):
    i=0
    c=[]
    while(i<len(a) or i<len(b)):
        if(i<len(a) and i<len(b)):
            c.append(a[i] - b[i])
        elif(i<len(a) and i>=len(b)):
            c.append(a[i])
        elif(i>=len(a) and i<len(b)):
            c.append(b[i])
        i=i+1
    print(c)

subtract(a,b)

def Sort(list):
    i=0
    while(i<len(list)):
        j=0
        while(j<len(list)-1):
            if(list[j]>list[j+1]):
                temp = list[j]
                list[j] = list[j+1]
                list[j+1] = temp
            j+=1
        i+=1
    print(list)

Sort(list)

def Max(list):
    i=0
    max = list[0]
    while(i<len(list)-1):
        if(list[i+1]>max):
            max = list[i+1]
        i=i+1
    print(max)
        
Max(list)


# ## Problem 11

# In[ ]:


#Done in IDLE mathematics.py(python33-Lib-sitepackages)
"""
a = [5,6,7,8,9]
b = [1,2,3,4]
list = [5,1,3,2,8] 

def add(a,b):
    i=0
    c=[]
    while(i<len(a) or i<len(b)):
        if(i<len(a) and i<len(b)):
            c.append(a[i] + b[i])
        elif(i<len(a) and i>=len(b)):
            c.append(a[i])
        elif(i>=len(a) and i<len(b)):
            c.append(b[i])
        i=i+1
    print(c)


def subtract(a,b):
    i=0
    c=[]
    while(i<len(a) or i<len(b)):
        if(i<len(a) and i<len(b)):
            c.append(a[i] - b[i])
        elif(i<len(a) and i>=len(b)):
            c.append(a[i])
        elif(i>=len(a) and i<len(b)):
            c.append(b[i])
        i=i+1
    print(c)


def Sort(list):
    i=0
    while(i<len(list)):
        j=0
        while(j<len(list)-1):
            if(list[j]>list[j+1]):
                temp = list[j]
                list[j] = list[j+1]
                list[j+1] = temp
            j+=1
        i+=1
    print(list)


def Max(list):
    i=0
    max = list[0]
    while(i<len(list)-1):
        if(list[i+1]>max):
            max = list[i+1]
        i=i+1
    print(max)
"""


# ## Problem 12

# In[10]:


#option
class Date(object):
    var1 = ""
    var2 = ""
    def __init__(self):
        Date.var1 = "ThursDay"
        Date.var2 = "October"

    def method(self):
        Date.var1 = (Date.var1, Date.var2, "2018")
        return Date.var1



class UseDate(Date):
    def __init__(self):
        print(Date.var1)
        print(Date.var2)

object1 = Date()
entire = object1.method()
object2 = UseDate()
print(entire)


# In[11]:


class Date(object):

    def __init__(self, var1, var2):
        self.var1 = var1
        self.var2 = var2

    def method(self):
        return self.var1 + " " + self.var2

class UseDate(Date):

    def __init__(self, var1, var2, var3):
        Date.__init__(self,var1, var2)
        self.var3 = var3

    def GetMethod(self):
        return self.method() + ", " +  self.var3

#x = Date("Thursday", "October")
y = UseDate("Friday", "October", "2018")

#print(x.method())
print(y.GetMethod())


# ## Problem 13

# In[6]:


#Done in IDLE
"""
file = "Assignment13.txt"
f = open(file,'a')
text = f.write("I am adding a new line in this text")
print(text)
f.close()
"""
"""
with open("Assignment13.txt") as f:
    with open("Output_Assignment13.txt", "w") as f1:
        for line in f:
            f1.write(line)

f.close()
f1.close()
"""


# ## Problem 14

# ### Numpy

# In[7]:


import numpy as np


# In[8]:


a = np.arange(15)
a


# In[9]:


a = a.reshape(3,5)
a


# In[10]:


a.ndim


# In[12]:


y = np.zeros((2,3,4))
y


# In[13]:


y.ndim


# ### Math function

# In[14]:


import math


# In[15]:


a=2.3
print ("The ceil of 2.3 is : ", end="") 
print (math.ceil(a)) 


# In[18]:


b=-10
math.fabs(b)


# In[19]:


c = 5
math.factorial(c)


# In[23]:


math.gcd(30,15)

