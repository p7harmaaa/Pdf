def Add(a,b):
    return a+b

def Sub(a,b):
    return a-b

def Sort(list):
    i=0
    while(i<len(list)):
        j=0
        while(j<len(list)-1):
            if(list[j]>list[j+1]):
                temp = list[j]
                list[j] = list[j+1]
                list[j+1] = temp
            j+=1
        i+=1
    print(list)

def Max(list):
    return max(list)



