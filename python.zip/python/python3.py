#g = lambda x:3*x+1
#g(6)

author = ["Stephen Hawking", "Jk Rowling", "Dan Brown"]
help(author.sort)

author.sort(key=lambda name:name.split(" ")[-1].lower()) 
print(author)
