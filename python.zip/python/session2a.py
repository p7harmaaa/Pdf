Python 3.3.0 (v3.3.0:bd8afb90ebf2, Sep 29 2012, 10:55:48) [MSC v.1600 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> ================================ RESTART ================================
>>> 
enter amt2000
Discount amt 200.0
net amt 1800.0
>>> ================================ RESTART ================================
>>> 
enter amt990
Discount amt 49.5
net amt 940.5
>>> ================================ RESTART ================================
>>> 
enter amt1002
Discount amt 100.2
net amt 901.8
>>> for i in "apple"
SyntaxError: invalid syntax
>>> for i in "apple"
SyntaxError: invalid syntax
>>> for i in "apple":
	print(i)

	
a
p
p
l
e
>>> tpl = ("apple","cherry")
>>> for i in tuple:
	print(i)

	
Traceback (most recent call last):
  File "<pyshell#8>", line 1, in <module>
    for i in tuple:
TypeError: 'type' object is not iterable
>>> 
>>> for i in tpl:
	print(i)

	
apple
cherry
>>> for i in range(1,11):
	for j in range(1,11):
		k=i*j
		print(k,end="")
	print()

	
12345678910
2468101214161820
36912151821242730
481216202428323640
5101520253035404550
6121824303642485460
7142128354249566370
8162432404856647280
9182736455463728190
102030405060708090100
>>> for i in range(1,11):
	for j in range(1,11):
		k=i*j
		print(k,end=" ")
	print()

	
1 2 3 4 5 6 7 8 9 10 
2 4 6 8 10 12 14 16 18 20 
3 6 9 12 15 18 21 24 27 30 
4 8 12 16 20 24 28 32 36 40 
5 10 15 20 25 30 35 40 45 50 
6 12 18 24 30 36 42 48 54 60 
7 14 21 28 35 42 49 56 63 70 
8 16 24 32 40 48 56 64 72 80 
9 18 27 36 45 54 63 72 81 90 
10 20 30 40 50 60 70 80 90 100 
>>> for i in range(1,5)
SyntaxError: invalid syntax
>>> for i in range(1,5):
	for j in range(i):
		print(i, end=" ")
	print()

	
1 
2 2 
3 3 3 
4 4 4 4 
>>> def first():
	print("hello python")

	
>>> first()
hello python
>>> first()
hello python
>>> def f(arg1)
SyntaxError: invalid syntax
>>> def f(arg1):
	print("hello", arg1)

	
>>> f("naveen")
hello naveen
>>> def multiply(arg1,arg2):
	result = arg1*arg2
	print(arg1, "x", arg2, "is", result)

	
>>> multiply(10,2)
10 x 2 is 20
>>> multiply(30, 67767)
30 x 67767 is 2033010
>>> def fun(arg_name, arg_age):
	print("name is", arg_name, "age is", arg_age)

	
>>> fun(arg_age = 20, arg_name = "naruto")
name is naruto age is 20
>>> def test(*args):
	k=0
	for i in args:
		k=k+i
	print(k)

	
>>> test(10,120,339,40)
509
>>> test(10,120,39,40)
209
>>> test(20,10)
30
>>> def test(**kwargs):
	for i in kwargs:
		print(kwargs[i])

		
>>> test(a="apple", b="ball", c="test")
apple
ball
test
>>> class First_Class:
	var1="Naruto"
	var2="Uzumaki"

	
>>> obj1 = First_Class()
>>> obj2 = First_Class()
>>> obj1.var1
'Naruto'
>>> obj1.var2
'Uzumaki'
>>> obj2.va
Traceback (most recent call last):
  File "<pyshell#70>", line 1, in <module>
    obj2.va
AttributeError: 'First_Class' object has no attribute 'va'
>>> obj2.var1
'Naruto'
>>> obj2.var2
'Uzumaki'
>>> obj2.var1 = "Kaneki"
>>> obj2.var2 = "Ken"
>>> obj1.var1
'Naruto'
>>> obj2.var1
'Kaneki'
>>> class Second_Class:
	def my_function(self):
		print("Inside Function")

		
>>> obj = Seconf_Class()
Traceback (most recent call last):
  File "<pyshell#81>", line 1, in <module>
    obj = Seconf_Class()
NameError: name 'Seconf_Class' is not defined
>>> obj = Second_Class()
>>> 
>>> obj.my_function()
Inside Function
>>> class MyClass:
	def __init__(self):
		print("This is Constructor")
		print("This also Print")

		
>>> obj = MyClass()
This is Constructor
This also Print
>>> 
