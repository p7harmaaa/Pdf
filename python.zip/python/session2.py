amt = int(input("enter amt"))
if (amt<1000):
    discount = amt * 0.05
    print("Discount amt", discount)
elif(amt<5000):
    discount = amt =0.01
else:
    discount=amt*0.1
    print("Discount amt", discount)
print("net amt", amt-discount)
