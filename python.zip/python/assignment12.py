"""
class Date:
    def __init__(self, day, month, year):
        self.day = day
        self.month = month
        self.year = year

    def Date1(self):
        return (self.day, " ", self.month, " ", year)

class UseDate(Date):

    def __init__(self, day, month, year, entire):
        Date.__init__(self,day, month, year)
        self.entire = entire

    def GetDate(self):
        return self.Date1() + ", " +  self.entire

x = Date("Thursday", "October", 2018)
y = UseDate("Thursday", "October", 2018, "1007")

print(x.Date1())
print(y.GetDate())
"""

class ClassA(object):
    var1 = 0
    var2 = 0
    def __init__(self):
        ClassA.var1 = 1
        ClassA.var2 = 2

    def methodA(self):
        ClassA.var1 = ClassA.var1 + ClassA.var2
        return ClassA.var1



class ClassB(ClassA):
    def __init__(self):
        print(ClassA.var1)
        print(ClassA.var2)

object1 = ClassA()
sum = object1.methodA()
object2 = ClassB()
print(sum)
