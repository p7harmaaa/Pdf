Python 3.3.0 (v3.3.0:bd8afb90ebf2, Sep 29 2012, 10:55:48) [MSC v.1600 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> "hello world"
'hello world'
>>> 12-10
2
>>> ================================ RESTART ================================
>>> 
Hello world
>>> ================================ RESTART ================================
>>> 
Hello world
{'sin', 'last', 'war'}
Hello World
>>> print(4+4)
8
>>> ================================ RESTART ================================
>>> 
Hello world
{'war', 'sin', 'last'}
Hello World
4
8
1
64
>>> var1 = "hello"
>>> print var1
SyntaxError: invalid syntax
>>> print(var1)
hello
>>> type(var1)
<class 'str'>
>>> var2 = 1
>>> type(var2)
<class 'int'>
>>> var3 = 1.2
>>> type(var3)
<class 'float'>
>>> str1 = "john"
>>> str1
'john'
>>> str2 = 'john'
>>> str2
'john'
>>> str2 = 'john's'"
SyntaxError: invalid syntax
>>> str2 = "john's"
>>> str2
"john's"
>>> str3 = "john"s"
SyntaxError: invalid syntax
>>> str3 = 'john"s'
>>> str3
'john"s'
>>> print('c:\demo\newfile.txt')
c:\demo
ewfile.txt
>>> print(r'c:\demo\newfile.txt')
c:\demo\newfile.txt
>>> var1 = 'hello'
>>> var2 = 'how are you"
SyntaxError: EOL while scanning string literal
>>> var2 = "how are you"
>>> var1*var2
Traceback (most recent call last):
  File "<pyshell#26>", line 1, in <module>
    var1*var2
TypeError: can't multiply sequence by non-int of type 'str'
>>> var1*2
'hellohello'
>>> var1*var2
Traceback (most recent call last):
  File "<pyshell#28>", line 1, in <module>
    var1*var2
TypeError: can't multiply sequence by non-int of type 'str'
>>> var1+var2
'hellohow are you'
>>> var1 = 5
>>> var2 = 3
>>> var1+var2
8
>>> var1-var2
2
>>> var1*var2
15
>>> var1/var2
1.6666666666666667
>>> var1%var2
2
>>> var1**var2
125
>>> var1//var2
1
>>> print(var1+var2, var1-var2, var1/var2, var1%var2)
8 2 1.6666666666666667 2
>>> var1=10
>>> var1
10
>>> var1+=5
>>> var1
15
>>> var1-=5
>>> var1
10
>>> var1/=5
>>> var1
2.0
>>> var1**2
4.0
>>> var1
2.0
>>> var1=5
>>> var2=3
>>> var1==var2
False
>>> var1>var2
True
>>> var1<var2
False
>>> var1!=var2
True
>>> var1<5 and var1<10
False
>>> var1<5 or var1<10
True
>>> not(var1<5 or var1<10)
False
>>> not(var1<5 and var1<10)
True
>>> x = ["apple", "banana"]
>>> y = ["apple", "banana"]
>>> z = x
>>> z
['apple', 'banana']
>>> x is z
True
>>> print
<built-in function print>
>>> print(x is z)
True
>>> x==z
True
>>> print(x is not z)
False
>>> print("apple" in x)
True
>>> print("mango" in x)
False
>>> print("mango" not in x)
True
>>> print("test") #this is for print
test
>>> len(sys.argv)
Traceback (most recent call last):
  File "<pyshell#74>", line 1, in <module>
    len(sys.argv)
NameError: name 'sys' is not defined
>>> ================================ RESTART ================================
>>> 
Hello world
{'sin', 'war', 'last'}
Hello World
4
8
1
64
Number of arguments : 1 arguments.
Arguments list: ['C:\\Users\\fenpatel\\python\\helloworld.py']
>>> a = b =c = 1
>>> a
1
>>> b
1
>>> c
1
>>> a,b,c = 1,2, "john"
>>> type(c)
<class 'str'>
>>> type(a)
<class 'int'>
>>> type(b)
<class 'int'>
>>> str = "Hello World"
>>> print(str)
Hello World
>>> print(str[0])
H
>>> str[2:5]
'llo'
>>> str[2:]
'llo World'
>>> str * 2
'Hello WorldHello World'
>>> str + "Test"
'Hello WorldTest'
>>> str[:2]
'He'
>>> list = ["abcd", 786, 2.23, "john", 70.2]
>>> tinylist = [123, "john"]
>>> list
['abcd', 786, 2.23, 'john', 70.2]
>>> list[0]
'abcd'
>>> list[1:3]
[786, 2.23]
>>> type(list)
<class 'list'>
>>> list[2:]
[2.23, 'john', 70.2]
>>> tinylist * 2
[123, 'john', 123, 'john']
>>> list + tinylist
['abcd', 786, 2.23, 'john', 70.2, 123, 'john']
>>> len(list)
5
>>> list.append("mango")
>>> list
['abcd', 786, 2.23, 'john', 70.2, 'mango']
>>> list.count("mango")
1
>>> list.append("mango")
>>> list.count("mango")
2
>>> list
['abcd', 786, 2.23, 'john', 70.2, 'mango', 'mango']
>>> list.index("mango")
5
>>> list1= list.copy()
>>> list1
['abcd', 786, 2.23, 'john', 70.2, 'mango', 'mango']
>>> list1.remove("mango")
>>> list1
['abcd', 786, 2.23, 'john', 70.2, 'mango']
>>> list.pop()
'mango'
>>> list
['abcd', 786, 2.23, 'john', 70.2, 'mango']
>>> list1.pop()
'mango'
>>> list1
['abcd', 786, 2.23, 'john', 70.2]
>>> list1.insert(1, "orange")
>>> list1
['abcd', 'orange', 786, 2.23, 'john', 70.2]
>>> list.reverse()
>>> list
['mango', 70.2, 'john', 2.23, 786, 'abcd']
>>> list.sort()
Traceback (most recent call last):
  File "<pyshell#123>", line 1, in <module>
    list.sort()
TypeError: unorderable types: float() < str()
>>> listcon = list(range(0,10))
Traceback (most recent call last):
  File "<pyshell#124>", line 1, in <module>
    listcon = list(range(0,10))
TypeError: 'list' object is not callable
>>> listcon = list(for i in range(0,10))
SyntaxError: invalid syntax
>>> tuple = (1,2,3,4,6)
>>> tpl
Traceback (most recent call last):
  File "<pyshell#127>", line 1, in <module>
    tpl
NameError: name 'tpl' is not defined
>>> tuple
(1, 2, 3, 4, 6)
>>> tuple[0]
1
>>> tuple[0]=100
Traceback (most recent call last):
  File "<pyshell#130>", line 1, in <module>
    tuple[0]=100
TypeError: 'tuple' object does not support item assignment
>>> list = [1,2,3,4,5]
>>> list.clear()
>>> list
[]
>>> del list
>>> list
<class 'list'>
>>> 
