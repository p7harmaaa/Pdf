a = [5,6,7,8,9]
b = [1,2,3,4]
list = [5,1,3,2,8] 
def add(a,b):
    i=0
    c=[]
    while(i<len(a) or i<len(b)):
        if(i<len(a) and i<len(b)):
            c.append(a[i] + b[i])
        elif(i<len(a) and i>=len(b)):
            c.append(a[i])
        elif(i>=len(a) and i<len(b)):
            c.append(b[i])
        i=i+1
    print(c)

add(a,b)

def subtract(a,b):
    i=0
    c=[]
    while(i<len(a) or i<len(b)):
        if(i<len(a) and i<len(b)):
            c.append(a[i] - b[i])
        elif(i<len(a) and i>=len(b)):
            c.append(a[i])
        elif(i>=len(a) and i<len(b)):
            c.append(b[i])
        i=i+1
    print(c)

subtract(a,b)

def Sort(list):
    i=0
    while(i<len(list)):
        j=0
        while(j<len(list)-1):
            if(list[j]>list[j+1]):
                temp = list[j]
                list[j] = list[j+1]
                list[j+1] = temp
            j+=1
        i+=1
    print(list)

Sort(list)

def Max(list):
    i=0
    max = list[0]
    while(i<len(list)-1):
        if(list[i+1]>max):
            max = list[i+1]
        i=i+1
    print(max)
        
Max(list)


